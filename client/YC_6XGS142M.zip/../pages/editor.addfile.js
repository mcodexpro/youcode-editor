import * as $ from '../export/editor.export.main';
import { filesAndCodeHandling } from '../core/editor.main';

var isSuccess = false;
$.qsa(".add-files", true).addEventListener("click", function() {

    var inputData = $.qsa(".editor-create-file-input input", true),
        rsupport = /\.(?:html|js|css)+$/,
        rinvalid = /[\\\/\:\*\?\|"\<\>]/,
        fileError = $.qsa(".editor-create-file-suggession-error", true);

    $.qsa(".editor-create-file-input", true).style.display = "";
    $.qsa(".editor-create-file-input input", true).focus();
    
    inputData.addEventListener("input", function() {
       
        if ( this.value && rinvalid.test( this.value ) ) {
            fileError.style.display = "block";
            fileError.innerHTML = `A file name '${ this.value }' can't contain any of the following [\/:&?|"<>] characters:`;

        } else if ( this.value && !rsupport.test( this.value ) ) {
            fileError.style.display = "block";
            fileError.innerHTML = "Unsupport language '" + inputData.value + "' please choose .html .css .js languages";

        } else {
            fileError.style.display = "none";
            fileError.innerHTML = "";
            isSuccess = true;
            return true;
        }
    } );
} );

function sendFileData() {
    $.qsa(".editor-create-file-input form", true).addEventListener("submit", function( e ) {
        e.preventDefault();

        if ( !isSuccess ) {
            return;
        }
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "./api/file.handling.php", true);
        xhr.onload = function() {
            if ( xhr.readyState === xhr.DONE && ( xhr.status >= 200 && xhr.status < 300 ) ) {
                if ( this.response !== "error" ) {
                    var data = document.createElement("span");
                    data.innerHTML = this.response;
                    insertCreatedFile( data );
                    inputData.value = ""; // reset file creater input value
                }
            }
        }
        xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhr.send("filename=" + inputData.value );
    } );
}
sendFileData();

function insertCreatedFile( data ) {
    $.ajax("./api/file.handling.php?show-files=true", function( res ) {
        var span = document.createElement("span");
        span.innerHTML = res;
        $.qsa(".editor-active-files-folders ul", true).appendChild( !!data ? data : span );
        filesAndCodeHandling();
    } );
}
insertCreatedFile();

$.qsa(".editor-active-files-folders ul", true).addEventListener("dblclick", function() {
    $.qsa(".editor-create-file-input", true).style.display = "";
    $.qsa(".editor-create-file-input input", true).focus();
} );

$.qsa(".editor-active-files-folders ul", true).addEventListener("contextmenu", function( e ) {
    e.preventDefault();
} );

var inputData = $.qsa(".editor-create-file-input input", true),
    match = $.qsa(".add-files", true), matched = match.querySelector("svg");

document.addEventListener("click", function( e ) {
    if ( !( e.target === inputData ||  e.target === match || e.target === matched || e.target === $.qsa(".new-file-add", true) ) ) {
        $.qsa(".editor-create-file-input", true).style.display = "none";
    }
} );

function refreshUploadedOrCreatedFiles() {
    [].slice.call($.qsa(".editor-active-files-folders ul li")).forEach( function( list ) {
        if ( list.className !== "editor-create-file-input" ) {
            list.parentNode.removeChild( list );
        }
    } );
    insertCreatedFile();
}

window.refreshUploadedOrCreatedFiles = refreshUploadedOrCreatedFiles;

$.qsa(".refresh-files-folders", true).addEventListener("click", function() {
    refreshUploadedOrCreatedFiles();
} );